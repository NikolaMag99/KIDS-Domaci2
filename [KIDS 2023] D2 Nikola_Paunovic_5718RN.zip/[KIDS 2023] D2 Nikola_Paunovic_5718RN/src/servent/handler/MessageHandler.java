package servent.handler;

/**
 * Currently merely a decorative interface. Might get more
 * substantial in the future.
 * @author bmilojkovic
 *
 */
public interface MessageHandler extends Runnable {

	
}
