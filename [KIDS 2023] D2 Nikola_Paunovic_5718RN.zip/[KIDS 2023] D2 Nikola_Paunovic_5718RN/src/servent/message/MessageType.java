package servent.message;

public enum MessageType {
	PING, PONG, POISON,
	TRANSACTION, TOKEN,
	AB_TELL,
	DONE, TERMINATE
}
