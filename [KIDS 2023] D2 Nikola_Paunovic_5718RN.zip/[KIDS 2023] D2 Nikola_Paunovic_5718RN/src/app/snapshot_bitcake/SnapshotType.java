package app.snapshot_bitcake;

public enum SnapshotType {
	ACHARYA_BADRINATH, ALAGAR_VENKATESAN, NONE
}
